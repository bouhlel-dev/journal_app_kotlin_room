package com.example.techdays

import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavHost
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.techdays.database.NoteDao
import com.example.techdays.database.NoteEntity

val WelcomeScreenRoute = "welcome"
val JournalScreenRoute = "journal"
val AddJournalScreenRoute = "add-journal"
val EditJournalScreenRoute = "edit-journal/{noteId}"


@Composable
fun NavGraph(
    getAllNotes: () -> List<NoteEntity>,
    getNoteById: (String) -> NoteEntity, // Added this function
    deleteNote: (NoteEntity) -> Unit,
    addNote: (note: NoteEntity) -> Unit,
    editNote: (note: NoteEntity) -> Unit,

    ) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = WelcomeScreenRoute,
    ) {

        // Welcome Screen
        composable(WelcomeScreenRoute) {
            WelcomeScreen(
                onContinue = {
                    navController.navigate(JournalScreenRoute)
                },
            )
        }

        // Journal Screen
        composable(JournalScreenRoute) {
            JournalScreen(
                addJournal = {
                    navController.navigate(AddJournalScreenRoute)
                },
                editJournal = {
                    navController.navigate(EditJournalScreenRoute)
                },


                getAllNotes = getAllNotes,
                deleteNote = deleteNote,
            )
        }

        // Add Journal Screen
        composable(AddJournalScreenRoute) {
            AddJournalScreen(
                addNote = addNote,
                navigateBack = {
                    navController.navigateUp()
                },
            )
        }

        // edit Journal Screen
        composable(
            route = EditJournalScreenRoute,
            arguments = listOf(
                navArgument("noteId") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val noteId = backStackEntry.arguments?.getString("noteId")
            EditJournalScreen(
                noteId = noteId ?: "",
                getNoteById = { id ->
                    getNoteById(id)
                },
                editNote = editNote,
                navigateBack = {
                    navController.navigateUp()
                }
            )
        }

    }

}

@Preview
@Composable
fun NavGraphPreview() {
    NavGraph(
        getAllNotes = { emptyList() },
        getNoteById = {NoteEntity("","","")}, // Provide a dummy function
        addNote = {},
        deleteNote = {},
        editNote = {}
    )
}